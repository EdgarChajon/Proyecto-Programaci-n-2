package com.Proyecto2024.ProyectoProgra2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoProgra2PuntoVentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoProgra2PuntoVentaApplication.class, args);
	}

}
